#include <linux/build-salt.h>
#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(.gnu.linkonce.this_module) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section(__versions) = {
	{ 0xa4b86400, "module_layout" },
	{ 0xa3ee9e12, "remove_proc_entry" },
	{ 0xf72c8b35, "unregister_kretprobe" },
	{ 0x8f5f598e, "misc_deregister" },
	{ 0xdb59a12d, "proc_create" },
	{ 0x14c8000e, "register_kretprobe" },
	{ 0xe007de41, "kallsyms_lookup_name" },
	{ 0x9a8377fc, "misc_register" },
	{ 0xc5850110, "printk" },
	{ 0x4c9d28b0, "phys_base" },
	{ 0xce807a25, "up_write" },
	{ 0x4fcc8ad2, "ex_handler_uaccess" },
	{ 0x57bc19d2, "down_write" },
	{ 0x26948d96, "copy_user_enhanced_fast_string" },
	{ 0xafb8c6ff, "copy_user_generic_string" },
	{ 0x72a98fdb, "copy_user_generic_unrolled" },
	{ 0x668b19a1, "down_read" },
	{ 0x53b954a2, "up_read" },
	{ 0x7cd8d75e, "page_offset_base" },
	{ 0x8a35b432, "sme_me_mask" },
	{ 0x1d19f77b, "physical_mask" },
	{ 0x294b9ea1, "on_each_cpu" },
	{ 0x593c1bac, "__x86_indirect_thunk_rbx" },
	{ 0xb6944c9c, "pid_task" },
	{ 0xe6885ec1, "find_vpid" },
	{ 0x1b44c663, "current_task" },
	{ 0xdecd0b29, "__stack_chk_fail" },
	{ 0x2ea2c95c, "__x86_indirect_thunk_rax" },
	{ 0xc7236d11, "cpu_tlbstate" },
	{ 0xb421a321, "pv_ops" },
	{ 0x445a81ce, "boot_cpu_data" },
	{ 0xbdfb6dbb, "__fentry__" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "A593B2D23DFB9F4CA107962");
