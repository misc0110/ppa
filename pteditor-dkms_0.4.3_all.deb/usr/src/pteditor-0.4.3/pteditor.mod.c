#include <linux/build-salt.h>
#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(.gnu.linkonce.this_module) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section(__versions) = {
	{ 0xc79d2779, "module_layout" },
	{ 0xb7a8281, "remove_proc_entry" },
	{ 0x767a6950, "unregister_kretprobe" },
	{ 0x8113162c, "misc_deregister" },
	{ 0x4c684ef, "proc_create" },
	{ 0x21540423, "register_kretprobe" },
	{ 0xe007de41, "kallsyms_lookup_name" },
	{ 0xaa3e21ef, "misc_register" },
	{ 0xc5850110, "printk" },
	{ 0x4c9d28b0, "phys_base" },
	{ 0x4fcc8ad2, "ex_handler_uaccess" },
	{ 0x2ea2c95c, "__x86_indirect_thunk_rax" },
	{ 0x26948d96, "copy_user_enhanced_fast_string" },
	{ 0xafb8c6ff, "copy_user_generic_string" },
	{ 0x72a98fdb, "copy_user_generic_unrolled" },
	{ 0x668b19a1, "down_read" },
	{ 0x53b954a2, "up_read" },
	{ 0x7cd8d75e, "page_offset_base" },
	{ 0x8a35b432, "sme_me_mask" },
	{ 0x1d19f77b, "physical_mask" },
	{ 0xdecd0b29, "__stack_chk_fail" },
	{ 0xb053cec, "native_write_cr4" },
	{ 0x3da0e677, "cpu_tlbstate" },
	{ 0x344fd44f, "pv_ops" },
	{ 0x445a81ce, "boot_cpu_data" },
	{ 0x294b9ea1, "on_each_cpu" },
	{ 0x593c1bac, "__x86_indirect_thunk_rbx" },
	{ 0xacebedfd, "pid_task" },
	{ 0x7d6286da, "find_vpid" },
	{ 0x4e0ecf27, "current_task" },
	{ 0xbdfb6dbb, "__fentry__" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "2F46960A6951168C5143685");
