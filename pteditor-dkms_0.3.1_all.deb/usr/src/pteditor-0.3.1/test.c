#include <stdio.h>

typedef struct {
    void* proc_lseek;
} u;

u umem_ops;

#define OP_lseek lseek
#define OPCAT(a, b) a ## b
#define OPS(o) OPCAT(umem_ops.proc_, o)

int main() {
    OPS(OP_lseek) = NULL;
}
